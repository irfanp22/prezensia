<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container m-auto my-7">
        <div class="mx-3 px-1">
            <div class="grid lg:grid-cols-3 gap-4 md:grid-cols-2 sm:grid-cols-1 ">
                <?php if($data): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container justify-self-center">
                    <div class="">
                        <div class="stack">
                            <div class="card w-90 glass mb-2 ">
                                <div class="card-body">
                                    <div class="card-actions justify-end m-0">
                                        <div class="dropdown dropdown-end">
                                            <label tabindex="0" class="btn m-1"><i class="fa-solid fa-ellipsis-vertical p-0"></i></label>
                                            <ul tabindex="0" class="dropdown-content menu p-2 shadow bg-base-100 rounded-box w-52">

                                            </ul>
                                        </div>
                                    </div>
                                    <h2 class="card-title"><?php echo e($d[0]); ?></h2>
                                    <p>Teacher :
                                        <?php if($d[1] == 1): ?>
                                        <span class="badge badge-success">You</span>
                                        <?php else: ?>
                                        <span><?php echo e(Str::limit($d[2], 24, '...')); ?> </span>
                                        <?php endif; ?>
                                    </p>
                                    <?php if($d[1]==1): ?>    
                                    <div class="card-actions justify-end">
                                        <button id='unarchive' class="btn btn-primary" data-id='<?php echo e($d[3]); ?>' data-modal-target="unarchive-modal" data-modal-toggle="unarchive-modal" type="button">Unarchive</button>
                                    </div>
                                    <?php else: ?>
                                    <div class="card-actions justify-end">
                                        <button class="btn btn-primary cursor-not-allowed focus:outline-none" type="button" disabled>Unarchive</button>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <img src="https://picsum.photos/id/44/4272/2848" alt="Image 1" class="w-80  rounded-box" />
                        </div>
                    </div>
                    <br>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('components.unarchive-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.classes-dial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.join-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function() {
            $('#unarchive').click(function() {
                var id = $(this).data('id')
                $('#accUnarch').attr('data-id', id);
            })
            $('#accUnarch').click(function() {
                var id = $(this).data('id');
                $.ajax({
                    url: '<?php echo e(route("classes.unarchive")); ?>'
                    , method: 'POST'
                    , data: {
                        '_token': '<?php echo e(csrf_token()); ?>'
                        , 'id': id
                    }
                    , success: function(response) {
                        if (response.msg == 'success') {
                            Swal.fire('Unarchive Success', '', 'success').then(function() {
                                window.location.assign('/archive');
                            });
                        }
                    }
                })
            })
        })

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/olaf/Project/preZensia/resources/views/archive.blade.php ENDPATH**/ ?>